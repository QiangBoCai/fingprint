
package com.hmdglobal.app.fingerprint;

public interface FingerFpCallback {
    public void onCmdResponse(int cmdId, byte[] result);
}
